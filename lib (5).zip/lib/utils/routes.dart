class MyRoutes {
  static String splashRoute = "/splash";
  static String loginRoute = "/login";
  static String homeRoute = "/home";
}
