

class Items {
  final int id;
  final String name;
  final String desc;
  final int prince;
  final String color;
  final String image;

  Items(this.id, this.name, this.desc, this.prince, this.color, this.image);

}