import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:untitled/utils/routes.dart';

class MyDrawer extends StatelessWidget {
  const MyDrawer({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    String name = "Meet Patel";
    String email = "meet@gmail.com";

    return Drawer(
      // backgroundColor: Colors.transparent,
      // child: Container(
      // color: Colors.deepPurple,
      child: ListView(
        children: [
          DrawerHeader(
            padding: EdgeInsets.zero,
            child: UserAccountsDrawerHeader(
              // decoration: const BoxDecoration(color: Colors.transparent),
              accountName: Text(name),
              accountEmail: Text(email),
              currentAccountPicture: const CircleAvatar(
                backgroundImage: NetworkImage(
                    "https://avatars.githubusercontent.com/u/64635467?v=4"),
              ),
            ),
          ),
          ListTile(
            onTap: () {},
            leading: const Icon(
              CupertinoIcons.home,
              color: Colors.black,
            ),
            title: const Text(
              "Home",
              // textScaleFactor: 1.5,
              style: TextStyle(fontSize: 20.2),
            ),
          ),
          ListTile(
            onTap: () {},
            leading: const Icon(
              CupertinoIcons.profile_circled,
              color: Colors.black,
            ),
            title: const Text(
              "Profile",
              // textScaleFactor: 1.5,
              style: TextStyle(fontSize: 20.2),
            ),
          ),
          ListTile(
            onTap: () => Navigator.pushNamed(context, MyRoutes.loginRoute),
            leading: const Icon(
              CupertinoIcons.lock_circle,
              color: Colors.black,
            ),
            title: const Text(
              "Login",
              // textScaleFactor: 1.5,
              style: TextStyle(fontSize: 20.2),
            ),
          ),
        ],
      ),
      // ),
    );
  }
}
